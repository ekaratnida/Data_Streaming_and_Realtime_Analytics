#!/bin/bash

sleep infinity