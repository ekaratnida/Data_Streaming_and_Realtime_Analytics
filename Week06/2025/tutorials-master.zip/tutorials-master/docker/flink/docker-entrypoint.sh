#!/bin/bash

sleep infinity