<!-- title: How to count the number of events in a Kafka topic with Kafka Streams -->
<!-- description: In this tutorial, learn how to count the number of events in a Kafka topic with Kafka Streams, with step-by-step instructions and supporting code. -->

# How to count the number of events in a Kafka topic with Kafka Streams

An aggregation in Kafka Streams is a stateful operation used to perform a "clustering" or "grouping" of values with
the same key.  An aggregation in Kafka Streams may return a different type than the input value.  In our example here
we're going to use the `count()` method to perform a count on the number of tickets sold.

``` java
 builder.stream(INPUT_TOPIC, Consumed.with(Serdes.String(), ticketSaleSerde))
        .map((k, v) -> new KeyValue<>(v.title(), v.ticketTotalValue()))
        .groupByKey(Grouped.with(Serdes.String(), Serdes.Integer()))
        .count()
        .toStream().mapValues(v -> v.toString() + " tickets sold")
        .to(OUTPUT_TOPIC, Produced.with(Serdes.String(), Serdes.String()));
```

Let's review the key points in this example

``` java
    map((key, value) -> new KeyValue<>(v.title(), v.ticketTotalValue()))
```  

Aggregations must group records by key.  Since the stream source topic doesn't define any, the code has a `map` operation which creates new key-value pairs setting the key of the stream to the `TicketSale.title` field.

``` java
        groupByKey(Grouped.with(Serdes.String(), Serdes.Integer()))
```

Since you've changed the key, under the covers Kafka Streams performs a repartition immediately before it performs the grouping.  
Repartitioning is simply producing records to an internal topic and consuming them back into the application.   By producing the records the updated keys land on
the correct partition. Additionally, since the key-value types have changed you need to provide updated `Serde` objects, via the `Grouped` configuration object
to Kafka Streams for the (de)serialization process for the repartitioning.

``` java
count()
```

The `count()` operator is a convenience aggregation method.  Under the covers it works like any other aggregation in Kafka Streams i.e. it requires an
`Initializer`, [Aggregator](https://javadoc.io/static/org.apache.kafka/kafka-streams/3.6.0/org/apache/kafka/streams/kstream/Aggregator.html) and a [Materialized](https://javadoc.io/static/org.apache.kafka/kafka-streams/3.6.0/org/apache/kafka/streams/kstream/Materialized.html) to set the `Serde` for the value since it's a `long`.  But since the result of this aggregation is a simple count, Kafka Streams handles all those details for you.

``` java
                .toStream().mapValues(v -> v + " tickets sold")
                .to(OUTPUT_TOPIC, Produced.with(Serdes.String(), Serdes.String()));

```
Aggregations in Kafka Streams return a [KTable](https://javadoc.io/static/org.apache.kafka/kafka-streams/3.6.0/org/apache/kafka/streams/kstream/KTable.html) instance, so it's converted to a [KStream](https://javadoc.io/static/org.apache.kafka/kafka-streams/3.6.0/org/apache/kafka/streams/kstream/KStream.html) then [mapValues](https://javadoc.io/static/org.apache.kafka/kafka-streams/3.6.0/org/apache/kafka/streams/kstream/KStream.html#mapValues-org.apache.kafka.streams.kstream.ValueMapper-) appends a string to the count to give it some context on the meaning of the number.

The following steps use Confluent Cloud. To run the tutorial locally with Docker, skip to the `Docker instructions` section at the bottom.

## Prerequisites

* A [Confluent Cloud](https://confluent.cloud/signup) account
* The [Confluent CLI](https://docs.confluent.io/confluent-cli/current/install.html) installed on your machine
* [Apache Kafka](https://kafka.apache.org/downloads) or [Confluent Platform](https://docs.confluent.io/platform/current/installation/installing_cp/zip-tar.html) (both include the Kafka Streams application reset tool)
* Clone the `confluentinc/tutorials` repository and navigate into its top-level directory:
  ```shell
  git clone git@github.com:confluentinc/tutorials.git
  cd tutorials
  ```

## Create Confluent Cloud resources

Login to your Confluent Cloud account:

```shell
confluent login --prompt --save
```

Install a CLI plugin that will streamline the creation of resources in Confluent Cloud:

```shell
confluent plugin install confluent-quickstart
```

Run the plugin from the top-level directory of the `tutorials` repository to create the Confluent Cloud resources needed for this tutorial. Note that you may specify a different cloud provider (`gcp` or `azure`) or region. You can find supported regions in a given cloud provider by running `confluent kafka region list --cloud <CLOUD>`.

```shell
confluent quickstart \
  --environment-name kafka-streams-aggregating-count-env \
  --kafka-cluster-name kafka-streams-aggregating-count-cluster \
  --create-kafka-key \
  --kafka-java-properties-file ./aggregating-count/kstreams/src/main/resources/cloud.properties
```

The plugin should complete in under a minute.

## Create topics

Create the input and output topics for the application:

```shell
confluent kafka topic create aggregation-count-input
confluent kafka topic create aggregation-count-output
```

Start a console producer:

```shell
confluent kafka topic produce aggregation-count-input
```

Enter a few JSON-formatted ticket sales:

```plaintext
{"title":"Guardians of the Galaxy", "ticketTotalValue":15}
{"title":"Doctor Strange", "ticketTotalValue":15}
{"title":"Guardians of the Galaxy", "ticketTotalValue":15}
```

Enter `Ctrl+C` to exit the console producer.

## Compile and run the application

Compile the application from the top-level `tutorials` repository directory:

```shell
./gradlew aggregating-count:kstreams:shadowJar
```

Navigate into the application's home directory:

```shell
cd aggregating-count/kstreams
```

Run the application, passing the Kafka client configuration file generated when you created Confluent Cloud resources:

```shell
java -cp ./build/libs/aggregating-count-standalone.jar \
    io.confluent.developer.KafkaStreamsAggregatingCount \
    ./src/main/resources/cloud.properties
```

Validate that you see the correct ticket sale counts per title in the `aggregation-count-output` topic.

```shell
confluent kafka topic consume aggregation-count-output -b --print-key --delimiter :
```

You should see:

```shell
Guardians of the Galaxy:2 tickets sold
Doctor Strange:1 tickets sold
```

## Clean up

When you are finished, delete the `kafka-streams-aggregating-count-env` environment by first getting the environment ID of the form `env-123456` corresponding to it:

```shell
confluent environment list
```

Delete the environment, including all resources created for this tutorial:

```shell
confluent environment delete <ENVIRONMENT ID>
```

<details>
  <summary>Docker instructions</summary>

  ## Prerequisites

  * Docker running via [Docker Desktop](https://docs.docker.com/desktop/) or [Docker Engine](https://docs.docker.com/engine/install/)
  * [Docker Compose](https://docs.docker.com/compose/install/). Ensure that the command `docker compose version` succeeds.
  * Clone the `confluentinc/tutorials` repository and navigate into its top-level directory:
    ```shell
    git clone git@github.com:confluentinc/tutorials.git
    cd tutorials
    ```

  ## Start Kafka in Docker

  Start Kafka with the following command run from the top-level `tutorials` repository directory:

  ```shell
  docker compose -f ./docker/docker-compose-kafka.yml up -d
  ```

  ## Create topics

  Open a shell in the broker container:

  ```shell
  docker exec -it broker /bin/bash
  ```

  Create the input and output topics for the application:

  ```shell
  kafka-topics --bootstrap-server localhost:9092 --create --topic aggregation-count-input
  kafka-topics --bootstrap-server localhost:9092 --create --topic aggregation-count-output
  ```

  Start a console producer:

  ```shell
  kafka-console-producer --bootstrap-server localhost:9092 --topic aggregation-count-input
  ```

  Enter a few JSON-formatted ticket sales:

  ```plaintext
  {"title":"Guardians of the Galaxy", "ticketTotalValue":15}
  {"title":"Doctor Strange", "ticketTotalValue":15}
  {"title":"Guardians of the Galaxy", "ticketTotalValue":15}
  ```
  
  Enter `Ctrl+C` to exit the console producer.

  ## Compile and run the application

  On your local machine, compile the app:

  ```shell
  ./gradlew aggregating-count:kstreams:shadowJar
  ```

  Navigate into the application's home directory:

  ```shell
  cd aggregating-count/kstreams
  ```

  Run the application, passing the `local.properties` Kafka client configuration file that points to the broker's bootstrap servers endpoint at `localhost:9092`:

  ```shell
  java -cp ./build/libs/aggregating-count-standalone.jar \
      io.confluent.developer.KafkaStreamsAggregatingCount \
      ./src/main/resources/local.properties
  ```

  Validate that you see the correct ticket sale counts per title in the `aggregation-count-output` topic. In the broker container shell:

  ```shell
  kafka-console-consumer --bootstrap-server localhost:9092 --topic aggregation-count-output --from-beginning --formatter-property "print.key=true" --formatter-property "key.separator=:"
  ```

  You should see:

  ```shell
  Doctor Strange:1 tickets sold
  Guardians of the Galaxy:2 tickets sold
  ```

  ## Clean up

  From your local machine, stop the broker container:

  ```shell
  docker compose -f ./docker/docker-compose-kafka.yml down
  ```
</details>
